﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyTitle("EyeOpen.Imaging.Processing")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Eye.Open")]
[assembly: AssemblyProduct("EyeOpen.Imaging.Processing")]
[assembly: AssemblyCopyright("Copyright © Eye.Open 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("0b7133f6-668f-42a9-8a86-c14c6aedeb5d")]

[assembly: AssemblyVersion("1.0.0.*")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum)]
[assembly: CLSCompliant(true)]