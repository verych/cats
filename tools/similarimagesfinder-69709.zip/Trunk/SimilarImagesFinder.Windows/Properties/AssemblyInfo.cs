﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("EyeOpen.Imaging.SimilarSearch")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Eye Open")]
[assembly: AssemblyProduct("EyeOpen.Imaging.SimilarSearch")]
[assembly: AssemblyCopyright("Copyright © Eye Open 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("80b1f979-2635-46b0-aca0-010da3e1f4fc")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]